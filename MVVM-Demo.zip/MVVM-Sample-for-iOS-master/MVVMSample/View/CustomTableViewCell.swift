//
//  CustomTableViewCell.swift
//  MVVMSample
//
//  Created by Venu Vodnala on 26/6/23.
//  Copyright © 2023 SacredBeastApp. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSubTitle: UILabel!
    
}
